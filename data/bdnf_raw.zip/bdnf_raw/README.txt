BDNF in mouse cortex: lab export
=================================

Protein: BDNF, measured in the nuclear fraction of cortex, arbitrary units (a.u.).
Mice: Control and Ts65Dn (a mouse model of Down syndrome).
Treatment: memantine or saline (injection).
Learning: C/S = context-shock (the mouse learned to fear the context);
          S/C = shock-context (control for learning: shock before exposure to the context).
Each mouse was measured 15 times (technical replicates of the same sample).

One file per group. File names: <genotype>_<treatment>_<learning>.
Control mice: Excel files. Ts65Dn mice: tab-separated text files (exported by a different person).
Missing readings were left empty, or written as NA or n/a.

Source: Higuera, Gardiner & Cios (2015) PLoS ONE 10(6): e0129126;
UCI Machine Learning Repository, DOI 10.24432/C50S3Z, licence CC BY 4.0.
